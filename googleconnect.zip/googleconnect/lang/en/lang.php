<?php return [
    'plugin' => [
        'name' => 'Google Connect',
        'description' => ''
    ]
];